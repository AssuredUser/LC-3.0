const buttonIds = [
  "ButtonA01",
  "ButtonA02",
  "ButtonA03",
  "ButtonA04",
  "ButtonA05",
  "ButtonA06",
  "ButtonA07",
  "ButtonA08",
  "ButtonA09",
  "ButtonA10",
  "ButtonA11",
  "ButtonA12",
  "ButtonA13",
  "ButtonA14",
  "ButtonA15",
  "ButtonA16",
  "ButtonA17",
  "ButtonA18",
  "ButtonA19",
  "ButtonA26",
  "ButtonA27",
  "ButtonA28",
  "ButtonA29",
  "ButtonA30",
  "ButtonA31",
  "ButtonA32",
  "ButtonA33",
  "ButtonA34",
  "ButtonA35",
  "ButtonA36",
  "ButtonA37",
  "ButtonA38",
  "ButtonA39",
  "ButtonA40",
  "ButtonA41",
  "ButtonA42",
  "ButtonB01",
  "ButtonB02",
  "ButtonB03",
  "ButtonB04",
  "ButtonB05",
  "ButtonB06",
  "ButtonB07",
  "ButtonB08",
  "ButtonB09",
  "ButtonB10",
  "ButtonB11",
  "ButtonB12",
  "ButtonB13",
  "ButtonB14",
  "ButtonB15",
  "ButtonB16",
  "ButtonB17",
  "ButtonB18",
  "ButtonB19",
  "ButtonB20",
  "ButtonB21",
  "ButtonB22",
  "ButtonB23",
  "ButtonB24",
  "ButtonB25",
  "ButtonB26",
  "ButtonC01",
  "ButtonC02",
  "ButtonC03",
  "ButtonC04",
  "ButtonC05",
  "ButtonC06",
  "ButtonC07",
  "ButtonC08",
  "ButtonC09",
  "ButtonC10",
  "ButtonC11",
  "ButtonC12",
  "ButtonC13",
  "ButoonC14",
  "ButtonC15",
  "ButtonC16",
  "ButtonC17",
  "ButtonC18",
  "ButtonC19",
  "ButtonC20",
  "ButtonC21",
  "ButtonC22",
  "ButtonC23",
  "ButtonC24",
  "ButtonC25",
  "ButtonC26",
  "ButtonC27",
  "ButtonC28",
  "ButtonC29",
  "ButtonC30",
  "ButtonC31",
  "ButtonC32",
  "ButtonC33",
  "ButtonC34",
  "ButtonC35",
  "ButtonC36"
];
let buttonsDisabled = false;

function toggleButtons() {
  buttonsDisabled = !buttonsDisabled;
  const disableButton = document.getElementById("disable-button");
  if (buttonsDisabled) {
    disableButton.style.backgroundColor = "blue";
  } else {
    disableButton.style.backgroundColor = "lightblue";
  }
}

function generateList() {
  const vacantList = [];
  const occupiedList = [];
  const unitInNeedOfServiceList = [];

  for (const buttonId of buttonIds) {
    const button = document.getElementById(buttonId);
    if (button === null) {
      // Button with id `buttonId` does not exist
      continue;
    }

    if (button.style.backgroundColor === "yellow") {
      vacantList.push(buttonId);
    } else if (button.style.backgroundColor === "red") {
      occupiedList.push(buttonId);
    } else if (button.style.backgroundColor === "orange") {
      unitInNeedOfServiceList.push(buttonId);
    }
  }

  console.log("Vacant list:", vacantList);
  console.log("Occupied list:", occupiedList);
  console.log("Unit in need of service list:", unitInNeedOfServiceList);
}

for (const buttonId of buttonIds) {
  const button = document.getElementById(buttonId);
  if (button === null) {
    // Button with id `buttonId` does not exist
    continue;
  }

  let numClicks = 0;
  button.addEventListener("click", () => {
    if (buttonsDisabled) {
      return;
    }
    numClicks++;
    if (numClicks === 1) {
      button.style.backgroundColor = "yellow";
    } else if (numClicks === 2) {
      button.style.backgroundColor = "red";
    } else if (numClicks === 3) {
      button.style.backgroundColor = "orange";
    } else if (numClicks === 4) {
      button.style.backgroundColor = "green";
    } else {
      button.style.backgroundColor = "white";
      numClicks = 0;
    }
  });
}

const disableButton = document.getElementById("disable-button");
disableButton.addEventListener("click", toggleButtons);
const generateListButton = document.getElementById("generate-list-button");
const listBox = document.getElementById("list-box");

generateListButton.addEventListener("click", function () {
  listBox.style.display = "block";

  // Get the current date and time
  const currentDateTime = new Date();

  // Create the heading
  const heading = `<strong>Location: Assured Storage of Clarksville Lot Check</strong><br>Date/Time: ${currentDateTime}`;

  // Get all buttons on the page
  const buttons = document.getElementsByTagName("button");

  // Initialize the list strings
  let vacantList = "";
  let overlockedList = "";
  let unitNeedsServiceList = "";
  let tytoList = "";

  // Loop through all buttons
  for (let i = 0; i < buttons.length; i++) {
    const button = buttons[i];
    const label = button.textContent;
    const backgroundColor = button.style.backgroundColor;

    // Add the button to the appropriate list based on its background color
    if (backgroundColor === "yellow") {
      vacantList += `- ${label}\n`;
    } else if (backgroundColor === "red") {
      overlockedList += `- ${label}\n`;
    } else if (backgroundColor === "orange") {
      unitNeedsServiceList += `- ${label}\n`;
    } else if (backgroundColor === "green") {
      tytoList += `- ${label}\n`;
    }
  }

  // Initialize the full list string
  let list = "";

  // If any of the lists are not empty, add the appropriate subheading and list
  if (vacantList !== "") {
    list += "Vacant:\n" + vacantList;
  }
  if (overlockedList !== "") {
    list += "Overlocked:\n" + overlockedList;
  }
  if (unitNeedsServiceList !== "") {
    list += "Unit Needs Service:\n" + unitNeedsServiceList;
  }
  if (tytoList !== "") {
    list += "TYTO:\n" + tytoList;
  }

  // Set the text of the list box to the heading and full list
  listBox.innerHTML = `${heading}<br>${list}`;
});

const resetButton = document.getElementById("reset-button");

resetButton.addEventListener("click", function () {
  // Loop through all buttons in the buttonIds array
  for (const buttonId of buttonIds) {
    const button = document.getElementById(buttonId);
    if (button === null) {
      // Button with id `buttonId` does not exist
      continue;
    }

    // Reset the background color of the button to white
    button.style.backgroundColor = "white";
  }
});
const pdfButton = document.getElementById("pdf-button");

pdfButton.addEventListener("click", function () {
  // Get the list-box element
  const listBox = document.getElementById("list-box");

  // Get the list of buttons from the list-box
  const list = listBox.textContent;

  // Create a new jsPDF object
  const doc = new jsPDF();

  // Add the list of buttons to the PDF
  doc.text(list, 10, 10);

  // Save the PDF
  doc.save("button-list.pdf");
});
// First, create a button and add it to your UI
